package com.demo.mapper;

import com.demo.pojo.Comment;
import org.apache.ibatis.annotations.Select;

public interface CommentMapper {
    @Select("SELECT * FROM t_comment WHERE id =#{id}")
    public Comment findById(Integer id);
}