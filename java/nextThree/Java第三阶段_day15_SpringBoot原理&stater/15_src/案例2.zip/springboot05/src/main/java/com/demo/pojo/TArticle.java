package com.demo.pojo;

import java.io.Serializable;
import lombok.Data;

/**
 * t_article
 * @author 
 */
@Data
public class TArticle implements Serializable {
    /**
     * 文章id
     */
    private Integer id;

    /**
     * 文章标题
     */
    private String title;

    /**
     * 文章内容
     */
    private String content;

    private static final long serialVersionUID = 1L;
}