package com.demo;

import com.demo.mapper.ArticleMapper;
import com.demo.pojo.TArticle;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class Springboot05ApplicationTests {

    @Autowired
    private ArticleMapper articleMapper;

    @Test
    void contextLoads2() {
        TArticle article = articleMapper.selectByPrimaryKey(1);
        System.out.println(article);
    }

}
