package com.demo.springbootdemo2;

import com.demo.springbootdemo2.controller.DemoController;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 *  SpringJUnit4ClassRunner.class:Spring运行环境
 *  JUnit4.class:JUnit运行环境
 *  SpringRunner.class:Spring Boot运行环境
 */
@RunWith(SpringRunner.class) //@RunWith:运行器
@SpringBootTest //标记为当前类为SpringBoot测试类，加载项目的ApplicationContext上下文环境
class Springbootdemo2ApplicationTests {
    /**
     * 需求：调用HelloController的hello方法
     */

    @Autowired
    private DemoController demoController;


    @Test
    void contextLoads() {
        String result = demoController.demo();
        System.out.println(result);
    }

}
