package com.example.demo.controller;

import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.List;

@Controller
@CrossOrigin(origins = "http://127.0.0.1:8081")
public class StudentController {
    /**
     * 服务对象
     */
    @Resource
    private StudentService studentService;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("selectOne")
    @ResponseBody
    public Student selectOne(Integer id) {
        return this.studentService.queryById(id);
    }

    /**
     * 根据条件查询数据
     * @param student
     * @return
     */
    @GetMapping("queryAll")
    @ResponseBody
    public List<Student> queryAll(Student student) {
        return this.studentService.queryAll(student);
    }

    /**
     * 分页查询
     * @return
     */

    @GetMapping("getStudent")
    public ModelAndView getStudent(){
        List<Student> students = this.studentService.queryAllByLimit(0,5);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("students",students);
        modelAndView.setViewName("students");
        return modelAndView;
    }

    @GetMapping("delete")
    public String delete(Integer id) throws  Exception{
            this.studentService.deleteById(id);
            return "redirect:/getStudent";

    }




}
