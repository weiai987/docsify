# Sentinel Cluster Flow Control

This is the default implementation of Sentinel cluster flow control.

- `sentinel-cluster-common-default`: common module for cluster transport and functions
- `sentinel-cluster-client-default`: default cluster client module using Netty as underlying transport library
- `sentinel-cluster-server-default`: default cluster server module