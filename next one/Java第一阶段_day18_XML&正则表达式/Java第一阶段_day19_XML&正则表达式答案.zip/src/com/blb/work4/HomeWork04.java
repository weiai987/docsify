package com.blb.work4;

import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
控制接收用户的输入,输入出生的日期,不匹配规则提示格式不正确,匹配的话你要提示今年多少岁了
扩展:提示你还有多少天过生日。
 */
public class HomeWork04 {
    public static void main(String[] args) {
//	1,用户输入

        Scanner input = new Scanner(System.in);
        System.out.println("请输入你的出生日期？（yyyy-MM-dd）");
        String birth =input.next();

        Pattern compile = Pattern.compile("(?<year>\\d{4})-(?<month>\\d{2})-(?<day>\\d{2})");
        Matcher matcher = compile.matcher(birth);
        Calendar now = Calendar.getInstance();
        if(matcher.find()){
//			求今年多少岁？
            String birthYear = matcher.group("year");
            int age = now.get(Calendar.YEAR)-Integer.parseInt(birthYear)  ;
            System.out.println("你今年"+age+"岁了。");
//			求还有多少天过生日？

            String birthMonth = matcher.group("month");
            String birthDay = matcher.group("day");

            Calendar c = Calendar.getInstance();
            c.set(Calendar.MONTH,Integer.parseInt(birthMonth)-1);
            c.set(Calendar.DAY_OF_MONTH,Integer.parseInt(birthDay));

            long l = c.getTimeInMillis()-now.getTimeInMillis() ;
            if(l>0){
                System.out.println("你还有"+(l/1000/60/60/24)+"天过生日。");

            }else{
//				 今年生日已经过了
                c.add(Calendar.YEAR, 1);
                long newTime = c.getTimeInMillis()-now.getTimeInMillis() ;
                System.out.println("你还有"+(newTime/1000/60/60/24)+"天过生日。");

            }

        }else{
            System.out.println("输入格式错误。");
        }


    }
}
