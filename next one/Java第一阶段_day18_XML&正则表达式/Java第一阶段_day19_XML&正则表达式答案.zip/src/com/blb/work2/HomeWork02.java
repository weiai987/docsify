package com.blb.work2;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

public class HomeWork02 {

    public static void main(String[] args) throws DocumentException {
        InputStream input = HomeWork02.class.getClassLoader().getResourceAsStream("china.xml");
        SAXReader saxReader = new SAXReader();
        Document document = saxReader.read(input);
        Element root = document.getRootElement();
        Iterator<Element> iterator = root.elementIterator();
        while (iterator.hasNext()) {
            Element pro = iterator.next();
            if("湖北".equals(pro.getName()) ){
                List<Element> elements = pro.elements();
                for (Element e:elements) {
                    System.out.println(e.getName());
                }
            }
        }
    }

}
