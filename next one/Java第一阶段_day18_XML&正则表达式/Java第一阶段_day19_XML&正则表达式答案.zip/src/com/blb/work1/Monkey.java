package com.blb.work1;

public class Monkey  extends Animal{
    private double height;

    public Monkey() {
    }

    public Monkey(double height) {
        this.height = height;
    }

    public Monkey(String name, int age, double height) {
        super(name, age);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
}
