package com.blb.work1;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.FileOutputStream;
import java.util.ArrayList;

public class Test {
    public static void main(String[] args) throws Exception {
        ArrayList<Animal> animals = new ArrayList<>();
        animals.add(new Elephant("胖胖",2,1.3));
        animals.add(new Elephant("肥仔",1,1.5));
        animals.add(new Elephant("憨憨",3,1.8));
        animals.add(new Monkey("星仔",3,0.8));
        animals.add(new Monkey("狒狒",4,0.9));
        animals.add(new Monkey("猴哥",5,1.0));
        createXml(animals);
    }

    public static void createXml(ArrayList<Animal> animals) throws Exception {
        //创建一个dom树
        Document doc = DocumentHelper.createDocument();
        //添加根节点
        Element ani = doc.addElement("animals");
        //遍历集合
        for (int i = 0; i < animals.size(); i++) {
            //添加子节点
            Element a = ani.addElement("animal");
            //给子节点添加子节点
            Element name = a.addElement("name");
            name.setText(animals.get(i).getName());
            Element age = a.addElement("age");
            //age.setText(Integer.toString(animals.get(i).getAge()));
            //age.setText(String.valueOf(animals.get(i).getAge()));
            age.setText(animals.get(i).getAge()+"岁");
            //判断 是大象还是猴子
            if(animals.get(i) instanceof Elephant){
                Element weight = a.addElement("weight");
                weight.setText(((Elephant) animals.get(i)).getWeight()+"吨");
            }else {
                Element height = a.addElement("height");
                height.setText(((Monkey) animals.get(i)).getHeight()+"米");
            }
        }
        //写入xml中
        FileOutputStream out = new FileOutputStream("day17/src/com/blb/work1/animal.xml");
        OutputFormat format = OutputFormat.createPrettyPrint();
        XMLWriter writer = new XMLWriter(out, format);
        writer.write(doc);
        writer.close();
    }
}
