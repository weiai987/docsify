package com.blb.work1;

public class Elephant extends Animal {
    private double weight;

    public Elephant() {
    }

    public Elephant(double weight) {
        this.weight = weight;
    }

    public Elephant(String name, int age, double weight) {
        super(name, age);
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
