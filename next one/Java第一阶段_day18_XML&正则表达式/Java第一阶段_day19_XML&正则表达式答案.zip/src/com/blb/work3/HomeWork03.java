package com.blb.work3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HomeWork03 {

    public static void main(String[] args) {
//  8-20位，小写字母/大写字母/数字中的至少两种

        String s = "1234567a9" ;

        if(!Pattern.matches(".{8,20}", s)){
            System.out.println("不满足8-20位");
            return ;
        }

        int count = 0 ;
        if(Pattern.matches(".*[a-z]+.*", s)){
            count++;
        }
        if(Pattern.matches(".*[A-Z]+.*", s)){
            count++;
        }
        if(Pattern.matches(".*[0-9]+.*", s)){
            count++;
        }

        if(count<2){
            System.out.println("不满足条件");
            return ;
        }

        System.out.println("满足条件");



    }
}
