package com.demo.product.service;

import com.demo.common.pojo.Products;

public interface ProductService {
    public Products findById(Integer productId);
}
