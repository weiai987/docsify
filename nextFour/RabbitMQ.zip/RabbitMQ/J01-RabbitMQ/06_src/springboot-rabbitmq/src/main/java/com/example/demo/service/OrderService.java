package com.example.demo.service;

import com.example.demo.pojo.Order;

public interface OrderService {

    int add(Order order);
}
