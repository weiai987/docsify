package com.demo.service;

import com.demo.pojo.User;

import java.util.List;

public interface UserService {

    public List<User> queryAll();

    public User findById(Integer id);

    public void insert(User user);

    public void deleteById(Integer id);

    public void update(User user);
}
