package com.demo.springbootdemo2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // 该注解为组合注解，等同于Spring中@Controller+@ResponseBody注解
public class DemoController {

    @RequestMapping("/demo")
    public String demo(){
        return "hello spring Boot";
    }
}
